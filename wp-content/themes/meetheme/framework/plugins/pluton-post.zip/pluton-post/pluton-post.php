<?php
/*
Plugin Name: Pluton Custom Post
Plugin URI: http://wordpress.org/
Description: Create new postype for pluton wp theme.
Author: pluton
Author URI: http://themeforest.net/user/plutonthemes
Version: 1.0.0
Text Domain: pluton
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/

define('PLUTON_POST_VERSION', '1.0.0');
define('PLUTON_POST_PATH', dirname(__FILE__));
require PLUTON_POST_PATH . '/inc/pluton_post_portfolio.php';